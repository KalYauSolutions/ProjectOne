package src.travelProfilePackage;

public class TravProf {
    String travAgentID;
    String firstName;
    String lastName;
    String address;
    String phone;
    float tripCost;
    String travelType;
    String paymentType;
    MedCond medCondInfo;

    public TravProf(String ID, String first, String last, String address, String phone, float cost, String travType,
                    String payType, MedCond medInfo) {
        this.travAgentID = ID;
        this.firstName = first;
        this.lastName = last;
        this.address = address;
        this.phone = phone;
        this.tripCost = cost;
        this.updateTravelType(travType); //checks the entry
        this.updatePaymentType(payType); //checks the entry
        this.medCondInfo = medInfo;
    }

    public String gettravAgentID() {
        return travAgentID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAddress(){
        return address;
    }

    public String getPhone(){
        return phone;
    }

    public float getTripCost(){
        return tripCost;
    }

    public String getTravelType(){
        return travelType;
    }

    public String getPaymentType(){
        return paymentType;
    }

    public MedCond getMedCondInfo(){
        return medCondInfo;
    }

    public void updateFirstName(String newFname){
        this.firstName = newFname;
    }

    public void updateLastName(String newLname){
        this.lastName = newLname;
    }

    public void updateAddress(String newAddress){
        this.address = newAddress;
    }

    public void updatePhone(String newPhone){
        this.phone = newPhone;
    }

    public void updateTripCost(float newCost){
        this.tripCost = newCost;
    }

    public void updateTravelType(String newTType){
        if ((newTType.equals("Pleasure"))||(newTType.equals("Business"))){ //Checks to see input is Business or Pleasure.
            this.travelType = newTType;
        }
    }

    public void updatePaymentType(String newPType){ //Checks to see input is Cash, Credit, Debit, or Invoice.
        if ((newPType.equals("Cash"))||
                (newPType.equals("Credit"))||
                (newPType.equals("Debit"))||
                (newPType.equals("Invoice"))){
            this.paymentType = newPType;
        }
    }

    public void updateMedCondInfo(MedCond newMedInfo) {
        this.medCondInfo = newMedInfo;
    }
    public static void main(String[] args){
    }
}