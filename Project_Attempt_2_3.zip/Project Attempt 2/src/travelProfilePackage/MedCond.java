package src.travelProfilePackage;

public class MedCond {
    String mdContact;
    String mdPhone;
    String algType;
    String illType;

    public MedCond(String physician, String medNum, String allergies, String illness){
        this.mdContact = physician;
        this.mdPhone = medNum;
        this.algType = allergies;
        this.illType = illness;
    }
    public String getMdContact(){
        return this.mdContact;
    }

    public String getMdPhone(){
        return this.mdPhone;
    }
    public String getAlgType(){
        return this.algType;
    }

    public String getIllType(){
        return this.illType;
    }

    public void updateMdContact(String newMdContact){
        this.mdContact = newMdContact;
    }

    public void updateMdPhone(String newMdPhone){
        this.mdPhone = newMdPhone;
    }

    public void updateAlgType(String newAlgType){
        this.algType = newAlgType;
    }

    public void updateIllType(String newIllType){
        this.illType = newIllType;
    }

    public static void main(String[] args){
    }
}