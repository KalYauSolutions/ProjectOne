package src.travelProfilePackage;

import java.io.*;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.*;

public class TravProf_DAO {
    TravProf[] travelerList = new TravProf[200]; //for now, just set to 200 entries
    int numTravelers = 0;
    int currentTravelerIndex = 0;
    String fileName;

    public TravProf_DAO(String fileAddress) {
        fileName = fileAddress;
    }

    public void insertNewProfile(TravProf profile) {
        // add profile to Array
        this.travelerList[this.currentTravelerIndex] = profile;
        this.currentTravelerIndex += 1;
        this.numTravelers += 1;
    }

    public boolean deleteProfile(String ID, String lastName) {
        //return true if profile successfully deleted
        for (int idx = 0; idx < this.travelerList.length; idx++) {
            if (travelerList[idx] == null) {
                continue;
            }
            else {
                TravProf currProfile = this.travelerList[idx];
                String currProfileID = currProfile.gettravAgentID();
                String currProfileLast = currProfile.getLastName();
                if ((currProfileID.equals(ID)) && (currProfileLast.equals(lastName))) {
                    travelerList[idx] = null;
                    return true;
                }
            }
        }
        return false;
    }

    public TravProf findProfile(String ID, String lastName){
        //return profile from DB by ID and lastName
        for (int idx=0; idx<this.travelerList.length; idx++) {
            if (travelerList[idx] == null){
                continue;
            }
            else {
                TravProf currProfile = this.travelerList[idx];
                String currProfileID = currProfile.gettravAgentID();
                String currProfileLast = currProfile.getLastName();
                if ((currProfileID.equals(ID)) && (currProfileLast.equals(lastName))){
                    return currProfile;
                }
            }
        }
        System.out.println("Profile specified was not found");
        return null;
    }

    public void writeAllTravProf() throws FileNotFoundException{
        //write all TravProf in travelerList to a file
        if (currentTravelerIndex == 0){
            return; //no profiles yet in array, don't write anything to file
        }
        else{
            try{
                FileWriter file = new FileWriter(fileName);
                JSONObject jo = new JSONObject();
                for (int idx = 0; idx < travelerList.length; idx++) {
                    if (travelerList[idx] == null) {
                        continue;
                    }
                    else {
                        TravProf currProfile = travelerList[idx];
                        jo.put("travAgentID", currProfile.gettravAgentID());//currentAgentID)
                        jo.put("firstName", currProfile.getFirstName());
                        jo.put("lastName", currProfile.getLastName());
                        jo.put("address", currProfile.getAddress());
                        jo.put("phone", currProfile.getPhone());
                        jo.put("tripCost", (float) currProfile.getTripCost());
                        jo.put("travelType", currProfile.getTravelType());
                        jo.put("paymentType", currProfile.getPaymentType());

                        MedCond med = currProfile.getMedCondInfo();
                        Map map = new LinkedHashMap(4);
                        map.put("mdContact", med.getMdContact());
                        map.put("mdPhone", med.getMdPhone());
                        map.put("algType", med.getAlgType());
                        map.put("illType", med.getIllType());
                        jo.put("medCondInfo", map);

                        file.write(jo.toJSONString());
                        file.write("\n");
                    }
                }
                file.close();
                return;
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public void initializeDatabase() throws Exception{
        //read all TravProf from file
        String line = null;
        JSONObject jo;
        try {
            FileReader reader = new FileReader(this.fileName);
            BufferedReader br = new BufferedReader(reader);

            while ((line = br.readLine()) != null) {
                jo = (JSONObject) new JSONParser().parse(line);
                String travAgentID = jo.get("travAgentID").toString();
                String firstName = jo.get("firstName").toString();
                String lastName = jo.get("lastName").toString();
                String address = jo.get("address").toString();
                String phone = jo.get("phone").toString();
                double tripCost = (double) jo.get("tripCost");
                float convTripCost = (float) tripCost;
                String travelType = jo.get("travelType").toString();
                String paymentType = jo.get("paymentType").toString();

                JSONObject medInfo = (JSONObject) jo.get("medCondInfo");
                String mdContact = medInfo.get("mdContact").toString();
                String mdPhone = medInfo.get("mdPhone").toString();
                String algType = medInfo.get("algType").toString();
                String illType = medInfo.get("illType").toString();

                MedCond medCondInfo = new MedCond(mdContact, mdPhone, algType, illType);
                TravProf profileToAdd = new TravProf(travAgentID,
                                                    firstName,
                                                    lastName,
                                                    address,
                                                    phone,
                                                    convTripCost,
                                                    travelType,
                                                    paymentType,
                                                    medCondInfo);
                this.insertNewProfile(profileToAdd);
            }
            br.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args){
        TravProf_DAO db = new TravProf_DAO("./profiles.json");

//        MedCond traveler2med = new MedCond("Dr.Marina", "1-800-Doc-Drew", "Peanuts", "Corona");
//        TravProf traveler2 = new TravProf("1337",
//                "Drew",
//                "Marina",
//                "WoodHaven also",
//                "555-Drew",
//                5000000.01f,
//                "Business",
//                "Credit",
//                traveler2med);
//        db.insertNewProfile(traveler2);

        try {
            //db.writeAllTravProf();
            //db.initializeDatabase();
            System.out.println(Arrays.toString(db.travelerList));
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
