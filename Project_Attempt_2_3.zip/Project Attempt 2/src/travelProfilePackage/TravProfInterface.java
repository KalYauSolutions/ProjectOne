package src.travelProfilePackage;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.concurrent.TimeUnit;



public class TravProfInterface {
    public static TravProf_DAO newDB = new TravProf_DAO("./profiles.json");

    public static void getUserChoice(String userID){
        boolean Finito = false;
        while(Finito == false) {
            System.out.println("1. Enter a new TravProf");
            System.out.println("2. Delete a traveler");
            System.out.println("3. Find and display a TravProf");
            System.out.println("4. Modify a TravProf");
            System.out.println("5. Display all profiles");
            System.out.println("6. Write to the TravProf DB");
            System.out.println("7. Initialise the TravProf DB");
            System.out.println("8. Exit");
            // First, we create a scanner to check for a users number input.
            Scanner userInput = new Scanner(System.in);
            String userNum = userInput.nextLine();
            switch (userNum) {
                case "1": //Replace this with a switch statement.
                    try {
                        newDB.insertNewProfile(createNewTravProf(userID));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    break;
                case "2":
                    try {
                        deleteTravProf(userID);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    break;
                case "3":
                    TravProf profDisplay = findTravProf(userID);
                    displayTravProf(profDisplay);
                    break;
                case "4":
                    updateTravProf(userID);
                    break;
                case "5":
                    displayAllTravProf(userID);
                    break;
                case "6":
                    writeToDB();
                    break;
                case "7":
                    initDB();
                    break;
                case "8":
                    Finito = true;
                    break;
                default:
                    System.out.println("Sorry, I don't understand. Please type a number.");
                    break;
            }
        }
        System.out.println("Thanks! Goodbye & Stay healthy!");

    }
    public static void deleteTravProf(String userID) throws InterruptedException{
        System.out.print("Are you sure? To confirm, enter the last name of the profile you wish to delete: ");
        Scanner delInput = new Scanner(System.in);
        String delName = delInput.nextLine();
        boolean didWeDelete = false;
        didWeDelete = newDB.deleteProfile(userID, delName);
        while (!didWeDelete){
            System.out.println("Hm...I wasn't able to delete this profile. Please ensure your ID was the one used to create the profile in the first place, then try again.");
            System.out.print("Once more, enter the last name of the profile you wish to delete: ");
            didWeDelete = newDB.deleteProfile(userID, delName);
        }
        System.out.println("Deleting profile...");
        Thread.sleep(1000);
        System.out.println("Done!");

    }
    public static TravProf findTravProf(String userID){
        System.out.print("Very well. Enter the last name of the profile you wish to display. Please note you can only see profiles you have created: ");
        Scanner findInput = new Scanner(System.in);
        String findName = findInput.nextLine();
        TravProf profResult = newDB.findProfile(userID, findName);
        while(profResult == null){
            System.out.println("Hm...I wasn't able to find this profile. Please ensure your ID was the one used to create the profile in the first place, then try again.");
            System.out.print("Once more, enter the last name of the profile you wish to find: ");
            findName = findInput.nextLine();
            profResult = newDB.findProfile(userID, findName);
        }
        System.out.println("Found.");
        return profResult;
    }
    public static void updateTravProf(String userID){
        TravProf modProf = findTravProf(userID);

        String modOption = null;
        while (modOption == null){
            System.out.println("Use your number keys to indicate which field you would like to update:");
            System.out.println("1. Address");
            System.out.println("2. Phone Number");
            System.out.println("3. Travel Type");
            System.out.println("4. Trip Cost");
            System.out.println("5. Payment Type");
            System.out.println("6. Medical Contact");
            System.out.println("7. Medical Contact Phone Number");
            System.out.println("8. Allergy Type");
            System.out.println("9. Illness Type");

            Scanner modInput = new Scanner (System.in);
            String modChoice = modInput.nextLine();
            switch (modChoice){
                case "1":
                    System.out.print("Please enter a new address: ");
                    String modAddress = modInput.nextLine();
                    modProf.updateAddress(modAddress);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "2":
                    System.out.print("Please enter a new phone number: ");
                    String modPhone = modInput.nextLine();
                    modProf.updatePhone(modPhone);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "3":
                    System.out.print("Please enter a new travel type: ");
                    String modTravType = modInput.nextLine();
                    while (!modTravType.equals("Pleasure") & !modTravType.equals("pleasure") & !modTravType.equals("Business") & !modTravType.equals("business")){
                        System.out.print("Apologies, but the string you entered is neither 'Business' and, quite frankly, nor is it 'Pleasure'. Try again :) : ");
                        modTravType = modInput.nextLine();
                    }
                    modProf.updateTravelType(modTravType);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "4":
                    System.out.print("Please enter a new trip cost: ");
                    float modCost = Float.parseFloat(modInput.nextLine());
                    modProf.updateTripCost(modCost);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "5":
                    String modPaymentType = null;
                    while(modPaymentType == null) {
                        System.out.print("Please update the payment type by typing 'Credit', 'Check', 'Debit', or 'Invoice'. DINERS CLUB IS NO LONGER ACCEPTED: ");
                        String modPaymentChoice = modInput.nextLine();
                        switch (modPaymentChoice) {
                            case "Credit":
                            case "credit":
                                modPaymentType = "Credit";
                                break;
                            case "Check":
                            case "check":
                                modPaymentType = "Check";
                                break;
                            case "Debit":
                            case "debit":
                                modPaymentType = "Debit";
                                break;
                            case "Invoice":
                            case "invoice":
                                modPaymentType = "Invoice";
                                break;
                            default:
                                modPaymentType = null;
                                System.out.println("Invalid payment type entered.");
                        }
                    }
                    modProf.updatePaymentType(modPaymentType);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "6":
                    System.out.print("Please enter a new medical contact: ");
                    String modMed = modInput.nextLine();
                    modProf.getMedCondInfo().updateMdContact(modMed);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "7":
                    System.out.print("Please enter a new medical contact phone number: ");
                    String newMedNum = modInput.nextLine();
                    modProf.getMedCondInfo().updateMdPhone(newMedNum);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "8":
                    String modAlgType = null;
                    while(modAlgType == null) {
                        System.out.print("Please update by typing 'none', 'food', 'medication', or 'other': ");
                        String modAlgChoice = modInput.nextLine();
                        switch (modAlgChoice) {
                            case "None":
                            case "none":
                                modAlgType = "None";
                                break;
                            case "Food":
                            case "food":
                                modAlgType = "Food";
                                break;
                            case "Medication":
                            case "medication":
                                modAlgType = "Medication";
                                break;
                            case "Other":
                            case "other":
                                modAlgType = "Other";
                                break;
                            default:
                                modAlgType = null;
                                System.out.println("Invalid allergy type entered.");
                        }
                    }
                    modProf.getMedCondInfo().updateAlgType(modAlgType);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                case "9":
                    String modIllType = null;
                    while(modIllType == null) {
                        System.out.print("Please update by typing 'none', 'heart', 'diabetes', 'asthma', or 'other': ");
                        String modIllChoice = modInput.nextLine();
                        switch (modIllChoice) {
                            case "None":
                            case "none":
                                modIllType = "None";
                                break;
                            case "Heart":
                            case "heart":
                                modIllType = "Heart";
                                break;
                            case "Diabetes":
                            case "diabetes":
                                modIllType = "Diabetes";
                                break;
                            case "Asthma":
                            case "asthma":
                                modIllType = "Asthma";
                                break;
                            case "Other":
                            case "other":
                                modIllType = "Other";
                                break;
                            default:
                                modIllType = null;
                                System.out.println("Invalid allergy type entered.");
                        }
                    }
                    modProf.getMedCondInfo().updateAlgType(modIllType);
                    modOption = "Field modified";
                    System.out.println(modOption);
                    break;
                default:
                    modOption = null;
                    System.out.println("Hm?");
            }
        }

    }
    public static void displayTravProf(TravProf prof){
        System.out.println("Displaying the profile of "+ prof.getFirstName()+ " " + prof.getLastName());
        System.out.println("First Name: "+ prof.getFirstName());
        System.out.println("Last Name: "+ prof.getLastName());
        System.out.println("Address: "+ prof.getAddress());
        System.out.println("Phone Number: "+ prof.getPhone());
        System.out.println("Trip Cost: "+ prof.getTripCost());
        System.out.println("Travel Type: "+ prof.getTravelType());
        System.out.println("Payment Type: "+ prof.getPaymentType());
        System.out.println("Physician: "+ prof.getMedCondInfo().getMdContact());
        System.out.println("Medical Contact Phone Number: "+ prof.getMedCondInfo().getMdPhone());
        System.out.println("Allergy Type: "+ prof.getMedCondInfo().getAlgType());
        System.out.println("Illness Type: "+ prof.getMedCondInfo().getIllType());
    }
    public static void displayAllTravProf(String userID){
        System.out.println("Gotcha. Here are all the profiles created by your current ID:");
        for(int i = 0;i<newDB.numTravelers;i++){
            if(newDB.travelerList[i] == null){
                continue;
            }
            else if(newDB.travelerList[i].travAgentID.equals(userID)){
                displayTravProf(newDB.travelerList[i]);
            }
        }
    }
    public static void writeToDB(){
        System.out.println("Writing to 'profiles.json'...");
        try {
            newDB.writeAllTravProf();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static void initDB(){
        System.out.println("Loading profiles from 'profiles.json'...");
        try {
            newDB.initializeDatabase();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static TravProf createNewTravProf(String userID) throws InterruptedException{
        System.out.print("To begin, please enter your (client's) first name: ");
        Scanner userInput = new Scanner(System.in);
        String newFirst = userInput.nextLine();
        userInput.reset();
        System.out.print("Next, please enter your last name: ");
        String newLast = userInput.nextLine();
        userInput.reset();
        System.out.print("Next, please enter your address: ");
        String newAddy = userInput.nextLine();
        userInput.reset();
        System.out.print("Next, please enter your home phone number: ");
        String newPhone = userInput.nextLine();
        userInput.reset();
        System.out.print("Next, please enter your estimated trip cost. Floats are fine!: ");
        float newCost = Float.parseFloat(userInput.nextLine());
        userInput.reset();
        System.out.print("Next, please choose your travel type, by typing 'Pleasure' or 'Business': ");
        String newTravType = userInput.nextLine();
        userInput.reset();
        while (!newTravType.equals("Pleasure") & !newTravType.equals("pleasure") & !newTravType.equals("Business") & !newTravType.equals("business")){
            System.out.print("Apologies, but the string you entered is neither 'Business' and, quite frankly, nor is it 'Pleasure'. Try again :) : ");
            newTravType = userInput.nextLine();
            userInput.reset();
        }
        String newPaymentType = null;
        while(newPaymentType == null) {
            System.out.print("How will you be paying? Please choose by typing 'Credit', 'Check', 'Debit', or 'Invoice'. DINERS CLUB IS NO LONGER ACCEPTED: ");
            String newPaymentChoice = userInput.nextLine();
            switch (newPaymentChoice) {
                case "Credit":
                case "credit":
                    newPaymentType = "Credit";
                    break;
                case "Check":
                case "check":
                    newPaymentType = "Check";
                    break;
                case "Debit":
                case "debit":
                    newPaymentType = "Debit";
                    break;
                case "Invoice":
                case "invoice":
                    newPaymentType = "Invoice";
                    break;
                default:
                    newPaymentType = null;
                    System.out.println("Invalid payment type entered.");
            }
        }
        userInput.reset();
        System.out.println("Analyzing user based off of entries...");
        Thread.sleep(1000);
        System.out.println("Interesting. I will now confirm your medical records with our human database.");
        TimeUnit.SECONDS.sleep(1);
        MedCond newMedCond = createNewMedCond();
        TravProf newProfile = new TravProf(userID, newFirst, newLast, newAddy, newPhone, newCost, newTravType, newPaymentType, newMedCond);
        return newProfile;
    }
    public static MedCond createNewMedCond(){
        System.out.print("To confirm, please enter the name of your client's physician: ");
        Scanner medInput = new Scanner(System.in);
        String newMdContact = medInput.nextLine();
        medInput.reset();
        System.out.print("And what is this physician's phone number?");
        String newMdPhone = medInput.nextLine();
        medInput.reset();
        System.out.println("Hmmm...that checks out with our data so far. Further questions:");
        String newAlgType = null;
        while(newAlgType == null) {
            System.out.print("What is your client's most pertinent allergy? Please choose by typing 'none', 'food', 'medication', or 'other': ");
            String newAlgChoice = medInput.nextLine();
            switch (newAlgChoice) {
                case "None":
                case "none":
                    newAlgType = "None";
                    break;
                case "Food":
                case "food":
                    newAlgType = "Food";
                    break;
                case "Medication":
                case "medication":
                    newAlgType = "Medication";
                    break;
                case "Other":
                case "other":
                    newAlgType = "Other";
                    break;
                default:
                    newAlgType = null;
                    System.out.println("Invalid allergy type entered.");
            }
        }
        medInput.reset();

        String newIllType = null;
        while(newIllType == null) {
            System.out.print("What is your client's most pertinent illness? Please choose by typing 'none', 'heart', 'diabetes', 'asthma', or 'other': ");
            String newIllChoice = medInput.nextLine();
            switch (newIllChoice) {
                case "None":
                case "none":
                    newIllType = "None";
                    break;
                case "Heart":
                case "heart":
                    newIllType = "Heart";
                    break;
                case "Diabetes":
                case "diabetes":
                    newIllType = "Diabetes";
                    break;
                case "Asthma":
                case "asthma":
                    newIllType = "Asthma";
                    break;
                case "Other":
                case "other":
                    newIllType = "Other";
                    break;
                default:
                    newIllType = null;
                    System.out.println("Invalid allergy type entered.");
            }
        }
        medInput.reset();

        System.out.println("Confirming all medical info...");
        System.out.println("Going back to main menu..." + "\n");
        return new MedCond(newMdContact, newMdPhone, newAlgType, newIllType);
    }//call this within createNewTravProf

    public static void main (String[] args){
        //ask for user's travAgent ID. If it doesn't exist, make one.
        System.out.println("To Log In, enter your travAgentID. Or, type 'n' to have a new ID generated for you.");
        Scanner initInput = new Scanner(System.in);
        String travAgentID = initInput.nextLine();

        TravProfInterface inter = new TravProfInterface(); //initialize Interface object
        List<String> agentList = new ArrayList<>(); //initialize TravelAgentID arrayList

        if (travAgentID.equals("n")){
            //make new TravAgentID, put it into JSON.
            String newID = "";
            int agentNumber = agentList.size() + 1;
            String agentNumStr = Integer.toString(agentNumber);
            newID += "TA";
            newID += agentNumStr;
            travAgentID = newID;
            System.out.println("New agent profile created! Your ID is: " + newID);
        }
        else if (agentList.size() == 0){
            System.out.println("No travel agent profiles available :(");
        }
        else {
            //an iterative search to see if the ID entered is on file.
            for (int i = 0; i <= agentList.size(); i++) {
                if (agentList.get(i).equals(travAgentID)) {
                    System.out.println("Very well...welcome " + travAgentID);
                    break;
                }
                else if (i == agentList.size()-1){
                    System.out.println("Sorry, the travel agent profile couldn't be found"); //reached end of array
                }
                else {
                    continue;
                }
            }
        }

        //We now display the list of options for our user.
        System.out.println("Please use your number keys to choose from the following options:");
        inter.getUserChoice(travAgentID);

    }
}
